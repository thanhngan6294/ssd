#include "mainwindow.h"
#include <QApplication>
#include <QTableWidget>
#include <QHeaderView>
#include <delegate.h>
#include <combobox.h>
#include <checkbox.h>
#include <QCheckBox>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle(QString::fromUtf8("QTableWidget Merge Cells Example"));
    w.resize(400,250);
    QTableWidget* table = new QTableWidget();

    //Set table row count 1 and column count 3
    table->setRowCount(10);
    table->setColumnCount(15);
    table->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    //Set Header Label Texts Here
    //table->setHorizontalHeaderLabels(QString("Message Name;Msg Params;Triggering;Data Field").split(";"));
    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);


    QTableWidgetItem* MessageName = new QTableWidgetItem("Message");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Msg Params");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    QTableWidgetItem *CycleTime = new QTableWidgetItem("Cycle Time [ms]");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    CycleTime->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    table->setItem(0,0,MessageName);
    table->setSpan(0,0,2,1);
    table->setItem(0,1,MsgParams);
    table->setSpan(0,1,1,2);
    table->setItem(0,3,Triggering);
    table->setSpan(0,3,1,4);
    table->setItem(0,7,DataField);
    table->setSpan(0,7,1,8);
    table->setItem(1,1,new QTableWidgetItem ("Channel",QFont::Black));
    table->setItem(1,2,new QTableWidgetItem ("DLC"));
    table->setItem(1,3,new QTableWidgetItem ("Send"));
    table->setItem(1,4,CycleTime);
    table->setSpan(1,4,1,3);
    table->setItem(1,7,new QTableWidgetItem ("0"));
    table->setItem(1,8,new QTableWidgetItem ("1"));
    table->setItem(1,9,new QTableWidgetItem ("2"));
    table->setItem(1,10,new QTableWidgetItem ("3"));
    table->setItem(1,11,new QTableWidgetItem ("4"));
    table->setItem(1,12,new QTableWidgetItem ("5"));
    table->setItem(1,13,new QTableWidgetItem ("6"));
    table->setItem(1,14,new QTableWidgetItem ("7"));
    ComboBoxDeleGate delegate;
    table->horizontalHeader()->setStretchLastSection(true);
    table->setItemDelegateForColumn(1,&delegate);
    ComboBox combobox;
    table->horizontalHeader()->setStretchLastSection(true);
    table->setItemDelegateForColumn(2,&combobox);
    table->setItem(2,3,new QTableWidgetItem ("now"));
    CheckBoxDeleGate checkbox;
    table->setItemDelegateForColumn(4,&checkbox);
    LabelDeleGate label;
    table->setItemDelegateForColumn(5,&label);
    SliderDeleGate slider;
    table->setItemDelegateForColumn(6,&slider);
    w.setCentralWidget(table);
    w.show();

    return a.exec();
}
